-- MySQL dump 10.13  Distrib 8.0.24, for Linux (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `category` varchar(45) NOT NULL,
  `img` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `popularity` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (25,2,'Async Vs Defer - JavaScript Loading Explanation','How The Browser Parses HTML\r\nBefore talking about speeding up script tag loading we first need to understand how the browser parses HTML. Luckily, for our purposes, it is pretty straight forward. The browser will parse HTML from the top of the document to the bottom, and when it hits a resource, like an img or link tag it will send out a request for that resource and continue parsing. The important thing to note is that the browser does not stop parsing the HTML to get the img src. This is why when you load a web page you may notice the page jumps around as the images pop in since they are loaded in the background and may finish downloading after the HTML is parsed. Below is an example of what the parsing looks like. The red highlighted text is code that has already been parsed. As you can see the parser does not stop on the img tag, and instead just keeps parsing.\r\n\r\nBrowser HTML parsing when there are no script tags\r\n\r\nBrowsers parse script tags a bit differently, though. Instead of continuing to parse once a script tag is encountered, the browser instead stops parsing, downloads the JavaScript, and executes it. This is why many times developers will put their script tags at the bottom of the HTML body so they do not delay the parsing of the HTML. As you can see in the below image, when the script tag is reached the parser stops parsing and waits for the JavaScript to download. This can lead to slow page speeds if the JavaScript files are large.\r\n\r\nBrowser HTML parsing with script tag in the head element Browser HTML parsing timeline for script tag in the head element\r\n\r\nYou may see this and just think that putting script tags at the bottom of the HTML body is ideal, but if the HTML file is large then the JavaScript will not start downloading until all the HTML is parsed which could significantly delay the JavaScript download. This is why the async and defer attributes were created.\r\n\r\nAsync Attribute Explained\r\nThe first attribute is the async attribute. To create an async script tag the following code is used . This attribute when applied to a script tag will make the script tag work just like img tags to the parser. This means the parser will download the JavaScript in the background and continue parsing as normal without waiting. When the JavaScript is done being downloaded then the parser will immediately stop parsing and execute the JavaScript. This is great for any small JavaScript code that is not dependent on anything else, but since the JavaScript is executed as soon as it is downloaded, the parser could still be delayed by JavaScript that takes a long time to execute. Another huge downside of the async attribute is that the JavaScript files are not executed in the order they are defined in the HTML. They are instead executed in the order they are downloaded. This means a quicker to download file will always execute before a slower to download file which can cause big problems if the JavaScript files are dependent on one another. Because of this, I rarely use async when loading script tags. The below video shows how the document is parsed when the async attribute is used.\r\n\r\nBrowser HTML parsing timeline for an async script tag in the head element\r\n\r\nDefer Attribute Explained\r\nSimilar to the async attribute, the defer attribute will not stop parsing to download the JavaScript. To create a defer script tag the following code is used . The parser will download the JavaScript in the background and continue parsing, but unlike the async attribute, the defer attribute will not execute the JavaScript until after the entire HTML document is parsed. This means that with the defer attribute the HTML parsing will never be delayed by the downloading of JavaScript. Also, since the JavaScript is executed after the entire HTML document is parsed the order of the JavaScript files is maintained. This is because all defer attribute JavaScript files must be downloaded before any of them can be executed. Because of this, I love the defer attribute and use it pretty much every time I load JavaScript. This is because I can put my JavaScript in the head of my HTML so it starts downloading as soon as possible, and it also preserves the order of my JavaScript as if it was loaded without the defer attribute. Loading JavaScript with the defer attribute is essentially the same as loading JavaScript at the end of the body, but it will start the download sooner. Also, since the executing of the JavaScript is always done after the HTML is parsed, there is no need to wait for document ready events. The document will always be ready when a defer attributed script tag is executed. Below is a video of how the defer attribute works.\r\n\r\nBrowser HTML parsing timeline for a defer script tag in the head element\r\n\r\nBrowser Support\r\nOf course, when talking about cool features in web development we have to talk about the dreaded browser support. Luckily for us, defer and async have incredible browser support. At the time of posting this article the defer attribute has 97.5% support, and the async attribute has 97.3% support. This is essentially the same level of support as flexbox which is amazing.\r\n\r\nConclusion\r\nIn conclusion if you want to load JavaScript faster so your page can render quicker you need to be using async or defer. In general the defer attribute should be the go to since it works nearly identically to normal script tag loading, but in special circumstances async tags can be useful for speeding up your page load.','2021-04-20 16:25:40','2021-04-25 10:37:26','development','js.jpg','How many times have you written ? Probably too many to count, but have you actually thought about how browsers handle that simple line of code? It is surprisingly more complex than it appears, which is why in this article I will be breaking down exactly how script tag loading works and most importantly how you can use async and defer to speed up your JavaScript load times.',47),(26,2,'Null Vs Undefined','To start I want to explain what null and undefined have in common since they are very similar. Both null and undefined mean that there is no value. If a variable is set to null or undefined it has no value and if a function returns null or undefined then it is saying it has no value to return. This you most likely already understand.\r\n\r\nThese values are actually so similar that they are considered equal when comparing with double equals (==).\r\n\r\nconsole.log(null == undefined)\r\n// true\r\nconsole.log(null === undefined)\r\n// false\r\nBecause of this, when I want to check to see if a variable has a value or not I almost always use double equals comparison since it will return true whether the variable is null or undefined.\r\n\r\nIf you want to learn more about double and triple equals check out my complete article on the topic linked here.\r\n\r\nThis is pretty much where the similarities end, though.\r\n\r\nNull\r\nIt is easiest to start with null when comparing the differences between null and undefined since null is very straightforward. If a variable is null then it means the variable has no value and that it was explicitly set to have no value by the programmer. A variable will never be null unless somewhere in the code a programmer set a variable to null.\r\n\r\nThis is important to know since when you see a null value you know that the programmer who wrote that code is telling you there is no value explicitly. A great example of where null is useful is in something like a find function that queries a database for an entry. If no entry exists it makes the most sense to return null since you are stating that there is no value found.\r\n\r\nUndefined\r\nOn the other hand undefined means that there is no value because no value has been set yet. For example, if you create a variable and do not assign it a value then it will be undefined.\r\n\r\nlet a\r\n\r\nconsole.log(a)\r\n// undefined\r\nWhere this gets a bit confusing is the fact that you can set a variable to undefined.\r\n\r\nlet a = null\r\n\r\nconsole.log(a)\r\n// null\r\n\r\na = undefined\r\nconsole.log(a)\r\n// undefined\r\nThe reason you would want to do this is to essentially reset a variable. By setting a variable to undefined you are conveying the message that the variable no longer contains any useful information, while if the value is null then you are specifically saying the result of some action has no value.\r\n\r\nTechnically, these both indicate no value, but they convey that message in slightly different ways.\r\n\r\nConclusion\r\nOverall it is not super important to know the differences between null and undefined other than how they interact with double and triple equals, but if you are diligent in your use of null and undefined you can write cleaner code that can make use out of the implicit/explicit nature of null and undefined.','2021-04-20 16:27:53','2021-04-23 23:41:59','development','js.jpg','JavaScript is quite confusing when it comes to a variable not having a value because it can be null or undefined. This leads to a lot of confusion, so in this article I will break down the differences between null and undefined.',13),(27,2,'Responsive CSS Aspect Ratio','HTML Video Tags\r\nThe video tag in HTML luckily makes creating responsive video incredibly easy. All you need to do is set the width to 100% and the height to auto.\r\n\r\nvideo {\r\n  height: auto;\r\n  width: 100%;\r\n}\r\nThis will create a video that fills the entire parent and its height will be calculated automatically based on the width so that it maintains its current aspect ratio no matter the screen size.\r\n\r\nIframes\r\nUnfortunately, iframes are not nearly as simple as the video tag. If we try the above trick of setting the width to 100% and the height to auto we will get an element that properly scales its width, but the height will always be 150px. This is because iframes default to 150px tall and ignore the aspect ratio of an embedded video.\r\n\r\nIf you are planning to embed video in an iframe from YouTube for example, then you need to get much more creative.\r\n\r\nThe best way to handle this situation is to wrap the iframe in a container that will maintain the correct aspect ratio and then just fill that container with the iframe. Here is the full code and then I will explain what is actually happening.\r\n\r\n\r\n  \r\n\r\n.video-container {\r\n  position: relative;\r\n  padding-bottom: 56.25%;\r\n  height: 0;\r\n  width: 100%;\r\n}\r\n\r\n.video-container iframe {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  width: 100%;\r\n  height: 100%;\r\n}\r\nExample\r\nTry resizing the example by dragging in the bottom right corner to watch the video scale.\r\n\r\n\r\nYou are probably looking at this code wondering how the heck it actually works and I don’t blame you. This code uses a CSS trick with padding to make everything work.\r\n\r\nWhen you use a percentage value for padding it will always be relative to the width of the element. This means if you have padding-top: 50% on an element that is 400px wide there will be 200px of padding on the top of the element no matter how tall it is. We can use this knowledge to set the padding of our element to the percentage ratio between our width and height.\r\n\r\nFor example, if the video is 16x9 then the percentage for padding would just be 9 / 16 which is 56.25%.\r\n\r\nWith just a small change to our code we could accommodate any aspect ratio.\r\n\r\n\r\n  \r\n\r\n.video-container {\r\n  position: relative;\r\n  padding-bottom: calc(var(--aspect-ratio, .5625) * 100%);\r\n  height: 0;\r\n  width: 100%;\r\n}\r\n\r\n.video-container iframe {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  width: 100%;\r\n  height: 100%;\r\n}\r\nBy changing just one line in the CSS we can now pass any custom aspect ratio and it will be calculated and converted to the correct percentage. If no aspect ratio is provided it will fall back to our standard 16x9 aspect ratio.\r\n\r\nConclusion\r\nMaking a video follow its aspect ratio at all screen sizes is confusing, but luckily the code to do so is short and easy to extend.','2021-04-20 16:30:37','2021-04-25 00:51:43','development','images.jpeg','Creating a video with an exact width and height is easy, but making that video scale with the size of the screen while also maintaining its aspect ratio is much harder especially when embedding a video from somewhere like YouTube.',8),(31,1,'title','555555','2021-04-21 15:24:04','2021-04-25 00:53:06','art-illustration','arch.jpg','vvvvvvvvvvv',14),(32,1,'mmmmmmmmm','aaaa','2021-04-22 10:58:14','2021-04-25 01:07:33','development','pexels-ekaterina-7140997.jpg','mmmm',5),(33,1,'vvvvvvvvvvv','aaa','2021-04-22 10:58:31','2021-04-24 00:19:23','development','Screenshot from 2021-04-12 17-01-38.png','vvvvvvvvvvv',4),(34,1,'aaaa','aaaaa','2021-04-22 10:58:47','2021-04-22 10:58:47','development','Screenshot from 2021-04-12 17-01-38.png','aaaa',1),(35,1,'asas','aaaaa','2021-04-22 10:58:59','2021-04-22 10:58:59','development','Screenshot from 2021-04-12 17-01-38.png','mmmm',1),(36,1,'asd','aaaaaa','2021-04-22 10:59:10','2021-04-22 10:59:10','development','Screenshot from 2021-04-12 17-01-38.png','vvvvvvvvvvv',1),(37,1,'mmmmmmmmm','aaaaaaaaa','2021-04-22 11:00:52','2021-04-22 11:00:52','development','Screenshot from 2021-04-12 17-01-38.png','mmmmmmmm',1),(38,1,'title','jkjkjkjk','2021-04-24 21:30:39','2021-04-24 21:30:39','art-illustration','Sprintive-Pattern.png','descriptuon',0),(40,1,'title','mmmm','2021-04-25 00:52:31','2021-04-25 00:54:20','architecture','art.jpeg','descriptuon',3),(41,1,'title',',,,mm','2021-04-25 00:53:02','2021-04-25 00:53:02','architecture','art.jpeg','descriptuon',0);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `article_id` int DEFAULT NULL,
  `body` mediumtext,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (42,31,'basil hammad','basil','basil@gmail.com'),(43,25,'test','basil','basilaaa@gmsssail.com'),(44,25,'basil hammad','omar','omar@gmail.com'),(45,25,'tsest','basil','basil@gmail.com'),(46,33,'basil','basil','basil@gmail.com'),(47,40,'test','basil','basil@gmail.com');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'basil','basil@gmail.com','$2y$10$mMBnusfztKFfiJsw45lTmOBN96bhqd7KBfmF2bZByvZpZKWsHKQ8C','2021-04-16 23:44:03'),(2,'omar','omar@gmail.com','$2y$10$C2L.YmLW8.V9vCJm.ND5bup94yunOOFhne204NxAGLe6AnAz5w/g2','2021-04-18 00:47:07'),(3,'yazeed','yazeed@hotmail.com','$2y$10$z3zpBATqvdQb8WUWIvPUs.Dbq60sSxOR3jV8icEMw33NHgYBdrQcm','2021-04-24 21:36:01');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-25 10:44:00
